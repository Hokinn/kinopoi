<?php

    $popular_movies = get_popular_movies();
    
?>

<div>
    <h2>Top 20 popular movies:</h2>
    <ul>
        <?php foreach($popular_movies['results'] as $movie) { ?>
        <li>
            <img src="<?php print TMDB_API_IMG_V3 . $movie['poster_path'] ?>" alt="movie">
            <h3><?php print $movie['title']; ?></h3>
        </li>
        <?php } ?>
    </ul>
</div>